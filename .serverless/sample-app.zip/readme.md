* deploy server as lambda function
npm install -g serverless
serverless config credentials --provider aws --key ACCESS_KEY ?secret SECRET_KEY